# cateye
SuperbAI Suite에서 OCR 데이터를 빠르고 편리하게 검사하기 위한 크롬확장프로그램입니다.
